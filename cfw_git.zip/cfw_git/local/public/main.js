cfw = angular.module('cfw', ['ngAnimate', 'firebase', 'ngRoute'])

.constant('SERVICE_BASE', window.location.protocol + '//' + window.location.host)

.provider('Url', ['SERVICE_BASE',
    function (SERVICE_BASE) {
        return {
            $get: function () {},
            Resolve: function (url) {

                // just add the leading slash if it has been omitted.
                if (url.charAt(0) !== '/') {
                    url = '/' + url;
                }
                return SERVICE_BASE + url;
            }
        };
    }])

.config(['$routeProvider', '$locationProvider', '$sceDelegateProvider', 'UrlProvider',
        function ($routeProvider, $locationProvider, $sceDelegateProvider, Url) {

        $locationProvider.html5Mode(true);

        $sceDelegateProvider.resourceUrlWhitelist([
            'self'
        ]);

        $routeProvider

        .when('/wods', {
            controller: 'wods'
        })
            .otherwise({
                redirectTo: '/'
            })

    }])

.run(['$rootScope', '$log', '$location',
    function ($rootScope, $log, $location) {
        $log.info("Welcome to Crossfit Westside");

        $rootScope.wods = false;
        $rootScope.$on('$locationChangeStart', function () {
            if ($location.path() !== '/wods') $rootScope.wods = false;
            if ($location.path() === '/wods') $rootScope.wods = true;
        });

    }]);


cfw.controller('main', ['$scope', '$location', '$firebase',
    function ($scope, $location, $firebase) {

        var ref = new Firebase("https://cfwswods.firebaseio.com/");
        var readOnlyWod = $firebase(ref);

        $scope.wodList = readOnlyWod.$asObject();

        $scope.navigate = function () {
            $location.path('/wods');
        }

}])


cfw.controller('wods', ['$scope', '$firebase', '$firebaseSimpleLogin',
    function ($scope, $firebase, $firebaseSimpleLogin) {

        var status = new Firebase("https://cfwswods.firebaseio.com/.info/authenticated");
        var ref = new Firebase("https://cfwswods.firebaseio.com/");

        var user = $firebaseSimpleLogin(ref);
        var wod = $firebase(ref);

        $scope.wod = wod.$asObject();

        $scope.saveWod = function () {
            var empty, removeEmpty;

            empty = $('.workoutitem').filter(function () {
                return !$(this).val();
            }).length;

            if (empty) {
                if (empty === $scope.wod.items.length) {
                    alert("Can't publish an empty workout.");
                } else {
                    removeEmpty = confirm("Remove empty fields?");
                }
            }

            $scope.wod.author = 'info@crossfitWestside.com';

            _.each($scope.wod.items, function (item) {
                delete item.$$hashKey;
                if (item.text.length > 250) alert("Text is too long");
                if (item.text === '' && removeEmpty) {
                    $scope.wod.items = _.without($scope.wod.items, item);
                }
            });

            $scope.wod.$save().then(function (ref) {
                alert("Workout was published!");
            });
        }

        status.on("value", function (snap) {
            if (snap.val() === true) {
                $scope.authed = true;
                reset();
            } else {
                $scope.authed = false;
            }
        });

        $scope.submitting = false;
        $scope.login = function (email, pass) {
            $scope.submitting = true;
            user.$login('password', {
                email: email,
                password: pass
            });
        }

        $scope.logout = function () {
            user.$logout();
        }


        function reset() {
            $scope.email = '';
            $scope.password = '';
            $scope.submitting = false;
        }
}]);

cfw.directive('wodItem', function () {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {



        }
    }

});

cfw.controller('getStarted', ['$scope', '$http',
    function ($scope, $http) {


        $scope.mailStatus = {};
        $scope.mailStatus.emailSent = false;
        $scope.mailStatus.emailError = false;
        $scope.mailStatus.sending = false;

        $scope.mail = {};

        $scope.sendMail = function (invalid) {

            if (!invalid) {

                $scope.mailStatus.sending = true;

                var email = {
                    key: "WlBwQV1KlMgoMnUbuCD3dw",
                    message: {
                        from_email: $scope.mail.email,
                        to: [
                            {
                                email: "info@crossfitwestside.com",
                                type: "to"
                        }
                    ],
                        subject: "CFWS Getting Started.",
                        autotext: true,
                        html: $scope.mail.name + " -- " + $scope.mail.email + " would like to get started!"
                    }
                }

                $http.post('https://mandrillapp.com/api/1.0/messages/send.json', email).
                success(function (data, status, headers, config) {
                    $scope.mailStatus.sending = false;
                    $scope.mailStatus.emailSent = true;
                    console.log('mail was sent.');
                }).
                error(function (data, status, headers, config) {
                    $scope.mailStatus.sending = false;
                    $scope.mailStatus.emailSent = true;
                    console.log('mail was not sent.');
                });
            }
        }

}]);

cfw.directive('coachBox', ['$timeout', '$rootScope',
    function ($timeout, $rootScope) {
        return {
            restrict: 'A',
            scope: true,
            link: function (scope, elem, attrs) {

                elem.find('.certs-link').on('click', function (e) {
                    e.preventDefault();
                    e.stopPropagation();
                });

                scope.$watch('open', function (open) {
                    if (open) $rootScope.$broadcast('close');
                });

                scope.$on('close', function (e, open) {
                    if ($(elem).hasClass('open'))
                        scope.open = false;
                });
            }
        }
}]);

cfw.directive('classSection', [
    function () {
        return {
            restrict: 'A',
            scope: true,
            link: function (scope, elem, attrs) {

                elem.on('click', function () {
                    console.log('refreshing skrollr ...')
                    s.refresh();
                })

            }
        }
}]);

cfw.directive('withDate', [
    function () {
        return {
            restrict: 'A',
            link: function (scope) {
                scope.date = moment().format('dddd MMMM Do YYYY');
            }
        }
}]);


$(document).ready(function () {

    // Menu settings
    $('#menuToggle, .menu-close').on('click', function () {
        opMenu();
    });

    $(".menu a").click(function () {
        opMenu();
    });

    function opMenu() {
        $('#menuToggle').toggleClass('active');
        $('#menuToggle span').toggleClass('mopen');
        $('body').toggleClass('body-push-toleft');
        $('#theMenu').toggleClass('menu-open');
        $('.menu-bar-logo').toggleClass('menu-open');
    }

    $('.flexslider').flexslider({
        animation: "fade",
        useCss: true,
        animationLoop: "true",
        slideshow: true,
        animationSpeed: 1000,
        controlNav: false,
        directionNav: true,
        easing: "swing",
        touch: true,
        after: function (slider) {

            $('.current-slide').text(slider.currentSlide + 1);
        },
        start: function (slider) {

            $('.current-slide').text(slider.currentSlide + 1);
            $('.total-slides').text(slider.count);
        }
    });

    var ss = smoothScroll.init({
        speed: 500, // Integer. How fast to complete the scroll in milliseconds
        easing: 'easeInOutQuad', // Easing pattern to use
        updateURL: false
    });

    var windowWidth = $(window).width();
    if (windowWidth > 480) {


        var s = skrollr.init({
            forceHeight: false,
            smoothScrolling: false
        });


    } else {

        $('.loader').remove();
        $('html').removeClass('locked');
    }

    $('#cbp-qtrotator').cbpQTRotator();

    function initializeMap() {
        var mapOptions = {
            center: new google.maps.LatLng(49.2673974, -123.1189956),
            zoom: 13,
            height: 400,
            styles: mapstyle,
            navigationControl: false,
            mapTypeControl: false,
            scaleControl: false,
            draggable: false,
            scrollwheel: false
        };

        var homeLatLng = new google.maps.LatLng(49.2673974, -123.1189956);

        var map = new google.maps.Map(document.getElementById("map-canvas"),
            mapOptions
        );

        var marker = new google.maps.Marker({
            position: homeLatLng,
            map: map,
            title: "We are here."
        });

        google.maps.event.addDomListener(window, 'resize', function () {
            var center = map.getCenter();
            google.maps.event.trigger(map, "resize");
            map.setCenter(center);
        });

    }


    initializeMap();

});

$(window).load(function () {

});