
/**
 * Module dependencies.
 */

var express = require('express')
  , routes = require('./routes')
  , http = require('http')
  , path = require('path');

var app = express();

// all environments
app.set('port', process.env.PORT || 3000);
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

app.set('view options', {
    layout: false
});

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', routes.index);
app.get('/wods', routes.index);
app.get('/wods/dailywod.xml', routes.rss);
app.get('/members', routes.members);

http.createServer(app).listen(app.get('port'), function(){
  console.log('Crossfit Westside | Express server listening on port ' + app.get('port'));
});
