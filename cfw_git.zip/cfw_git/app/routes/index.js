
/*
 * GET home page.
 */

exports.index = function(req, res){
  res.sendfile('public/index.html');
};

exports.faq = function(req, res){
    res.sendfile('public/partials/faq.html');
};

var RSS = require('rss');
var Firebase = require('firebase');
var wodRef = new Firebase('https://cfwswods.firebaseio.com/');

exports.rss = function(req, res){
   wodRef.once("value", function(snap){

           var data = snap.val();

           var feed = new RSS({
               title: 'Crossfit Westside - RSS Feed',
               description: 'Crossfit Westside - Workout of the day',
               feed_url: 'http://www.crossfitwestside.com/wods/dailywod.xml',
               site_url: 'http://www.crossfitwestside.com',
               author: 'info@crossfitwestide.com',
               language: 'en',
               date: data.date
           });

           data.items.forEach(function(e, index){
               if(!data.items[index].heading){
                   feed.item({
                       title: 'Workout Item #' + (index+1),
                       description: data.items[index].text
                   });
               }
           })

           var xml = feed.xml();
           res.set('Content-Type', 'text/xml');
           res.send(xml);

   });
}
exports.members = function(req, res){
    res.sendfile('public/partials/members.html');
};
